package finishreason

const (
	Stop = "stop"
)
