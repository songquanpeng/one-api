package role

const (
	Assistant = "assistant"
)
