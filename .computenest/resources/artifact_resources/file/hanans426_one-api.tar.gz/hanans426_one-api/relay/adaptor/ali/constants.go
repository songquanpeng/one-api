package ali

var ModelList = []string{
	"qwen-turbo", "qwen-plus", "qwen-max", "qwen-max-longcontext",
	"text-embedding-v1",
	"ali-stable-diffusion-xl", "ali-stable-diffusion-v1.5", "wanx-v1",
}
