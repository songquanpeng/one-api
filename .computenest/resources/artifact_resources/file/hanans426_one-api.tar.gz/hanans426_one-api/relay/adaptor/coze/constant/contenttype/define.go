package contenttype

const (
	Text = "text"
)
