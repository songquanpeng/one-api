package deepseek

var ModelList = []string{
	"deepseek-chat",
	"deepseek-coder",
}
