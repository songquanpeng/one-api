package baichuan

var ModelList = []string{
	"Baichuan2-Turbo",
	"Baichuan2-Turbo-192k",
	"Baichuan-Text-Embedding",
}
