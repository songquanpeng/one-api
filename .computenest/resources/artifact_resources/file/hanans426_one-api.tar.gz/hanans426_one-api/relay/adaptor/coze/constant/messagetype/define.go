package messagetype

const (
	Answer   = "answer"
	FollowUp = "follow_up"
)
