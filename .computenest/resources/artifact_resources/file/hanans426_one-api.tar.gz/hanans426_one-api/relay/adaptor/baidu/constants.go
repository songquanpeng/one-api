package baidu

var ModelList = []string{
	"ERNIE-4.0-8K",
	"ERNIE-3.5-8K",
	"ERNIE-3.5-8K-0205",
	"ERNIE-3.5-8K-1222",
	"ERNIE-Bot-8K",
	"ERNIE-3.5-4K-0205",
	"ERNIE-Speed-8K",
	"ERNIE-Speed-128K",
	"ERNIE-Lite-8K-0922",
	"ERNIE-Lite-8K-0308",
	"ERNIE-Tiny-8K",
	"BLOOMZ-7B",
	"Embedding-V1",
	"bge-large-zh",
	"bge-large-en",
	"tao-8k",
}
