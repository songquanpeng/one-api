package tencent

var ModelList = []string{
	"hunyuan-lite",
	"hunyuan-standard",
	"hunyuan-standard-256K",
	"hunyuan-pro",
	"hunyuan-vision",
}
