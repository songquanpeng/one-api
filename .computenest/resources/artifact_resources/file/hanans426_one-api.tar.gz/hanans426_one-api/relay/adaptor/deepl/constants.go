package deepl

// https://developers.deepl.com/docs/api-reference/glossaries

var ModelList = []string{
	"deepl-zh",
	"deepl-en",
	"deepl-ja",
}
