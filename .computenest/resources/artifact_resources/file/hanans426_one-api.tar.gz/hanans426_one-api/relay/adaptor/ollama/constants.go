package ollama

var ModelList = []string{
	"codellama:7b-instruct",
	"llama2:7b",
	"llama2:latest",
	"llama3:latest",
	"phi3:latest",
	"qwen:0.5b-chat",
	"qwen:7b",
}
