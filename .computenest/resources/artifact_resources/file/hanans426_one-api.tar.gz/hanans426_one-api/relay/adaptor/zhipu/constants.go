package zhipu

var ModelList = []string{
	"chatglm_turbo", "chatglm_pro", "chatglm_std", "chatglm_lite",
	"glm-4", "glm-4v", "glm-3-turbo", "embedding-2",
	"cogview-3",
}
