package groq

// https://console.groq.com/docs/models

var ModelList = []string{
	"gemma-7b-it",
	"mixtral-8x7b-32768",
	"llama3-8b-8192",
	"llama3-70b-8192",
	"gemma2-9b-it",
	"llama-3.1-405b-reasoning",
	"llama-3.1-70b-versatile",
	"llama-3.1-8b-instant",
	"llama3-groq-70b-8192-tool-use-preview",
	"llama3-groq-8b-8192-tool-use-preview",
	"whisper-large-v3",
}
