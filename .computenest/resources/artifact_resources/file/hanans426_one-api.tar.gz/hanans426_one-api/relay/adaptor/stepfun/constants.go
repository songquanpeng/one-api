package stepfun

var ModelList = []string{
	"step-1-8k",
	"step-1-32k",
	"step-1-128k",
	"step-1-256k",
	"step-1-flash",
	"step-2-16k",
	"step-1v-8k",
	"step-1v-32k",
	"step-1x-medium",
}
