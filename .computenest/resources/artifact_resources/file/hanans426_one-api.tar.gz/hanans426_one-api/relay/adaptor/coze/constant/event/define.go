package event

const (
	Message = "message"
	Done    = "done"
	Error   = "error"
)
