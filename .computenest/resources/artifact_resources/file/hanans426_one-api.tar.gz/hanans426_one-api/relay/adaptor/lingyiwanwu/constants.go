package lingyiwanwu

// https://platform.lingyiwanwu.com/docs

var ModelList = []string{
	"yi-34b-chat-0205",
	"yi-34b-chat-200k",
	"yi-vl-plus",
}
