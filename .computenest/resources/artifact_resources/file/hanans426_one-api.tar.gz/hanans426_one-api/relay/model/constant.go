package model

const (
	ContentTypeText     = "text"
	ContentTypeImageURL = "image_url"
)
