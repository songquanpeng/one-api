const LOG_TYPE = {
  0: { value: '0', text: '全部', color: '' },
  1: { value: '1', text: '充值', color: 'primary' },
  2: { value: '2', text: '消费', color: 'orange' },
  3: { value: '3', text: '管理', color: 'default' },
  4: { value: '4', text: '系统', color: 'secondary' }
};

export default LOG_TYPE;
