package helper

const (
	RequestIdKey = "X-Oneapi-Request-Id"
)
