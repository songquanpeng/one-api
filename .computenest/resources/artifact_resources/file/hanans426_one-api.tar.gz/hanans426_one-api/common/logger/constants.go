package logger

var LogDir string
